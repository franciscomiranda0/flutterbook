package francisco.flutter_book

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
